function calculateEntropy(password) {
    if (!password) return { score: 0, text: "Empty", color: "#ef4444", seconds: 0 };
    let pool = 0;
    if (/[a-z]/.test(password)) pool += 26;
    if (/[A-Z]/.test(password)) pool += 26;
    if (/[0-9]/.test(password)) pool += 10;
    if (/[^A-Za-z0-9]/.test(password)) pool += 32;
    
    const entropy = password.length * Math.log2(pool || 1);
    const seconds = Math.pow(2, entropy) / 100000000000; 
    
    if (seconds < 3600) return { score: 1, text: "Cracked in minutes", color: "#ef4444", seconds };
    if (seconds < 86400 * 30) return { score: 2, text: "Cracked in days", color: "#f59e0b", seconds };
    if (seconds < 86400 * 365 * 10) return { score: 3, text: "Cracked in years", color: "#eab308", seconds };
    return { score: 4, text: "Cracked in centuries", color: "#22c55e", seconds };
}

document.addEventListener('DOMContentLoaded', async () => {
    let activeKey = null;
    let currentEditId = null;
    let verifyMode = 'signup'; 
    let tempAccountData = null;

    const screens = {
        setup: document.getElementById('setupScreen'),
        verify: document.getElementById('verifyScreen'),
        login: document.getElementById('loginScreen'),
        vault: document.getElementById('vaultScreen'),
        edit: document.getElementById('editArea'),
        settings: document.getElementById('settingsSection')
    };

    const data = await chrome.storage.local.get(['salt', 'verify', 'thresholdDays', 'email']);
    const thresholdDays = data.thresholdDays || 5;
    updateSegmentedUI(thresholdDays);

    if (!data.salt) {
        screens.setup.classList.remove('hidden');
    } else {
        screens.login.classList.remove('hidden');
    }

    async function deriveKey(password, salt) {
        const encoder = new TextEncoder();
        const baseKey = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
        return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, baseKey, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
    }

    async function encrypt(text, key) {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
        return { ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted))), iv: btoa(String.fromCharCode(...iv)) };
    }

    async function decrypt(blob, key) {
        try {
            const binaryString = atob(blob.ciphertext);
            const ciphertext = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) ciphertext[i] = binaryString.charCodeAt(i);
            const ivString = atob(blob.iv);
            const iv = new Uint8Array(ivString.length);
            for (let i = 0; i < ivString.length; i++) iv[i] = ivString.charCodeAt(i);
            const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
            return new TextDecoder().decode(decrypted);
        } catch (e) { return null; }
    }

    document.getElementById('toLoginLink').addEventListener('click', () => {
        screens.setup.classList.add('hidden');
        screens.login.classList.remove('hidden');
    });

    document.getElementById('toSignupLink').addEventListener('click', () => {
        screens.login.classList.add('hidden');
        screens.setup.classList.remove('hidden');
    });

    document.getElementById('settingsBtn').addEventListener('click', () => screens.settings.classList.remove('hidden'));
    document.getElementById('closeSettings').addEventListener('click', () => screens.settings.classList.add('hidden'));

    document.getElementById('addNewBtn').addEventListener('click', () => {
        currentEditId = null;
        document.getElementById('editTitle').textContent = "New Credential";
        ['siteUrl', 'username', 'password'].forEach(id => document.getElementById(id).value = '');
        updateStrengthMeter('');
        screens.edit.classList.remove('hidden');
    });

    document.getElementById('cancelEdit').addEventListener('click', () => screens.edit.classList.add('hidden'));

    document.getElementById('openDashboardBtn').addEventListener('click', () => {
        chrome.tabs.create({ url: 'dashboard.html' });
    });

    const passInput = document.getElementById('password');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');

    passInput.addEventListener('input', () => updateStrengthMeter(passInput.value));

    function updateStrengthMeter(password) {
        const e = calculateEntropy(password);
        strengthBar.style.width = (e.score * 25) + '%';
        strengthBar.style.background = e.color;
        strengthText.textContent = password ? `Entropy: ${e.text}` : '';
        strengthText.style.color = e.color;
    }

    document.getElementById('generatePassBtn').addEventListener('click', () => {
        const p = Array.from(crypto.getRandomValues(new Uint8Array(20))).map(x => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*".charAt(x%72)).join('');
        passInput.value = p;
        updateStrengthMeter(p);
    });

    document.getElementById('unlockBtn').addEventListener('click', async () => {
        const pass = document.getElementById('masterPassword').value;
        const d = await chrome.storage.local.get(['salt', 'verify']);
        if(!d.salt) return;
        const salt = new Uint8Array(atob(d.salt).split('').map(c => c.charCodeAt(0)));
        const key = await deriveKey(pass, salt);
        const check = await decrypt(d.verify, key);
        
        if (check === "success") { 
            activeKey = key;
            const exp = await crypto.subtle.exportKey('raw', key);
            chrome.runtime.sendMessage({ action: 'set_session_key', key: btoa(String.fromCharCode(...new Uint8Array(exp))) });
            screens.login.classList.add('hidden');
            screens.vault.classList.remove('hidden');
            loadCredentials();
            setInterval(loadCredentials, 10000); 
        } else {
            document.getElementById('loginError').classList.remove('hidden');
        }
    });

    document.getElementById('saveBtn').addEventListener('click', async () => {
        const site = document.getElementById('siteUrl').value.trim();
        const user = document.getElementById('username').value.trim();
        const pass = document.getElementById('password').value.trim();
        if (!site || !user || !pass) return;

        const encryptedPass = await encrypt(pass, activeKey);
        const d = await chrome.storage.local.get({ vault: [] });
        
        if (currentEditId) {
            d.vault = d.vault.map(item => item.id === currentEditId ? { ...item, site, username: user, passwordBlob: encryptedPass, lastUsed: Date.now(), notified: false, isLeaked: false, leaks: 0 } : item);
        } else {
            d.vault.push({ id: Date.now(), site, username: user, passwordBlob: encryptedPass, lastUsed: Date.now(), notified: false, isLeaked: false, leaks: 0 });
        }
        await chrome.storage.local.set({ vault: d.vault });
        screens.edit.classList.add('hidden');
        loadCredentials();
    });

    async function loadCredentials() {
        if (!activeKey) return;
        const d = await chrome.storage.local.get({ vault: [], thresholdDays: 5 });
        const list = document.getElementById('credentialsList');
        const thresholdMillis = d.thresholdDays * 60 * 1000;
        const now = Date.now();

        list.innerHTML = '';
        d.vault.forEach(item => {
            const isDormant = (now - item.lastUsed) > thresholdMillis;
            const isLeaked = item.isLeaked;

            const card = document.createElement('div');
            card.className = `vault-card ${isDormant || isLeaked ? 'dormant' : ''}`;
            card.innerHTML = `
                <div class="card-info">
                    <span class="card-site">${item.site}</span>
                    <span class="card-user">${item.username}</span>
                    ${isDormant ? '<div class="badge red">Dormant</div>' : ''}
                    ${isLeaked ? '<div class="badge red" style="background:#fee2e2; color:#b91c1c;">Leaked</div>' : ''}
                </div>
                <div class="card-actions">
                    ${isLeaked || isDormant ? `<a href="https://${item.site.toLowerCase().replace(/ /g, '') + '.com'}/.well-known/change-password" target="_blank" class="action-btn" title="Fix Now" style="text-decoration:none; font-size:10px; font-weight:800; color:#b91c1c;">Fix</a>` : ''}
                    <button class="action-btn copy" data-id="${item.id}" title="Copy Password">C</button>
                    <button class="action-btn edit" data-id="${item.id}" title="Edit">E</button>
                </div>
            `;
            list.appendChild(card);
        });

        list.querySelectorAll('.copy').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const el = e.currentTarget;
                const id = parseInt(el.dataset.id);
                const item = d.vault.find(v => v.id === id);
                const p = await decrypt(item.passwordBlob, activeKey);

                if (p) { 
                    navigator.clipboard.writeText(p); 
                    const orig = el.innerHTML;
                    el.innerHTML = '<span style="font-size:8px; font-weight:800">OK</span>'; 
                    setTimeout(() => el.innerHTML=orig, 1500); 

                    const data = await chrome.storage.local.get({ vault: [] });
                    data.vault = data.vault.map(v => v.id === id ? { ...v, lastUsed: Date.now(), notified: false } : v);
                    await chrome.storage.local.set({ vault: data.vault });
                    loadCredentials();
                }
            });
        });

        list.querySelectorAll('.edit').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                const item = d.vault.find(v => v.id === id);
                currentEditId = item.id;
                document.getElementById('editTitle').textContent = "Update Account";
                document.getElementById('siteUrl').value = item.site;
                document.getElementById('username').value = item.username;
                const p = await decrypt(item.passwordBlob, activeKey);
                document.getElementById('password').value = p || '';
                updateStrengthMeter(p || '');
                screens.edit.classList.remove('hidden');
            });
        });

        updateHealth(d.vault, d.thresholdDays);
    }

    function updateHealth(vault, days) {
        const threshold = days * 60 * 1000;
        let penalty = 0;
        vault.forEach(v => {
            if ((Date.now() - v.lastUsed) > threshold) penalty += 0.5;
            if (v.isLeaked) penalty += 2;
        });
        const pct = vault.length === 0 ? 100 : Math.max(0, 100 - (penalty * (100 / vault.length)));
        document.getElementById('healthScore').textContent = Math.round(pct) + "%";
        document.getElementById('healthFill').style.width = pct + "%";
        document.getElementById('healthFill').style.background = pct > 80 ? "#22c55e" : (pct > 50 ? "#f59e0b" : "#ef4444");
    }

    document.querySelectorAll('#thresholdSelector button').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const val = parseInt(e.currentTarget.dataset.value);
            await chrome.storage.local.set({ thresholdDays: val });
            updateSegmentedUI(val);
            loadCredentials();
        });
    });

    function updateSegmentedUI(value) {
        document.querySelectorAll('#thresholdSelector button').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.value == value);
        });
    }

    document.getElementById('lockVaultBtn').addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'lock_vault' });
        location.reload();
    });

    document.getElementById('logoutBtn').addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'lock_vault' });
        location.reload();
    });

    document.getElementById('initVaultBtn').addEventListener('click', () => {
        const email = document.getElementById('userEmail').value;
        const pass = document.getElementById('newMasterPassword').value;
        if (!email || pass.length < 8) return alert("Valid email and 8+ character password required.");
        
        const randomOTP = Math.floor(100000 + Math.random() * 900000).toString();
        tempAccountData = { email, pass, otp: randomOTP };
        
        verifyMode = 'signup';
        chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: ' Verification', message: `Your signup code is: ${randomOTP}`, priority: 2 });
        screens.setup.classList.add('hidden');
        screens.verify.classList.remove('hidden');
    });

    document.getElementById('deleteVaultBtn').addEventListener('click', () => {
        if(confirm("DANGER: Permanent wipe. Are you sure?")) {
            chrome.storage.local.clear();
            chrome.runtime.sendMessage({ action: 'lock_vault' });
            location.reload();
        }
    });

    document.getElementById('confirmVerifyBtn').addEventListener('click', async () => {
        const code = Array.from(document.querySelectorAll('.otp-input')).map(i => i.value).join('');
        if (verifyMode === 'signup' && code === tempAccountData.otp) {
            const { email, pass } = tempAccountData;
            const salt = crypto.getRandomValues(new Uint8Array(16));
            const saltBin = String.fromCharCode(...salt);
            const key = await deriveKey(pass, salt);
            const verifyBlob = await encrypt("success", key);
            await chrome.storage.local.set({ email, salt: btoa(saltBin), verify: verifyBlob, vault: [], thresholdDays: 5, legacyEnabled: false, legacyDays: 180 });
            location.reload();
        }
    });

    document.querySelectorAll('.otp-input').forEach((input, idx, inputs) => {
        input.addEventListener('keyup', (e) => {
            if (e.key >= 0 && e.key <= 9 && idx < 5) inputs[idx + 1].focus();
            else if (e.key === 'Backspace' && idx > 0) inputs[idx - 1].focus();
        });
    });
});