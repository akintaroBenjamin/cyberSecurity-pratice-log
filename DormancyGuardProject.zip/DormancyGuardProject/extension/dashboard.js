// dashboard.js - Enterprise Edition (Soft Mono)
let activeKey = null;
let currentEditId = null;
let verifyMode = 'signup'; 
let tempAccountData = null;

// --- Entropy Calculator ---
function calculateEntropy(password) {
    if (!password) return { score: 0, text: "Empty", color: "#71717a", seconds: 0 };
    let pool = 0;
    if (/[a-z]/.test(password)) pool += 26;
    if (/[A-Z]/.test(password)) pool += 26;
    if (/[0-9]/.test(password)) pool += 10;
    if (/[^A-Za-z0-9]/.test(password)) pool += 32;
    
    const entropy = password.length * Math.log2(pool || 1);
    const seconds = Math.pow(2, entropy) / 100000000000; 
    
    if (seconds < 3600) return { score: 1, text: "Seconds", color: "#ef4444", seconds };
    if (seconds < 86400 * 30) return { score: 2, text: "Days", color: "#f59e0b", seconds };
    if (seconds < 86400 * 365 * 10) return { score: 3, text: "Years", color: "#eab308", seconds };
    return { score: 4, text: "Centuries", color: "#22c55e", seconds };
}

document.addEventListener('DOMContentLoaded', async () => {
    // Cache selectors with null checks
    const get = (id) => document.getElementById(id);
    const screens = {
        authContainer: get('authScreens'),
        appScreens: get('appScreens'),
        setup: get('setupScreen'),
        verify: get('verifyScreen'),
        login: get('loginScreen'),
        editModal: get('editDashModal')
    };

    // --- Crypto Helpers ---
    async function deriveKey(password, salt) {
        const encoder = new TextEncoder();
        const baseKey = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']);
        return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, baseKey, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
    }
    
    async function encrypt(text, key) {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
        return { ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted))), iv: btoa(String.fromCharCode(...iv)) };
    }
    
    async function decrypt(blob, key) {
        try {
            const binaryString = atob(blob.ciphertext);
            const ciphertext = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) ciphertext[i] = binaryString.charCodeAt(i);
            const ivString = atob(blob.iv);
            const iv = new Uint8Array(ivString.length);
            for (let i = 0; i < ivString.length; i++) iv[i] = ivString.charCodeAt(i);
            const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
            return new TextDecoder().decode(decrypted);
        } catch (e) { return null; }
    }

    // --- Initialization ---
    const storageData = await chrome.storage.local.get(['salt', 'verify', 'thresholdDays', 'email', 'webAuthnEnabled']);
    const sessionResponse = await chrome.runtime.sendMessage({ action: 'get_session_key' });
    
    if (storageData.webAuthnEnabled && get('webauthnLoginBtn')) {
        get('webauthnLoginBtn').classList.remove('hidden');
    }

    if (sessionResponse && sessionResponse.key) {
        try {
            const rawKey = new Uint8Array(atob(sessionResponse.key).split('').map(c => c.charCodeAt(0)));
            activeKey = await crypto.subtle.importKey('raw', rawKey, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
            showDashboard();
        } catch (e) {
            screens.authContainer.classList.remove('hidden');
            screens.login.classList.remove('hidden');
        }
    } else if (!storageData.salt) {
        screens.authContainer.classList.remove('hidden');
        screens.setup.classList.remove('hidden');
        screens.login.classList.add('hidden');
    } else {
        screens.authContainer.classList.remove('hidden');
        screens.login.classList.remove('hidden');
    }

    // --- Navigation (Robust Listener) ---
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            const target = e.currentTarget;
            if (target.id === 'dashLogoutBtn') {
                chrome.runtime.sendMessage({ action: 'lock_vault' });
                location.reload();
                return;
            }

            const tabId = target.getAttribute('data-tab');
            if (!tabId) return;

            // Update Nav UI
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            target.classList.add('active');

            // Update Tabs
            document.querySelectorAll('.tab-section').forEach(sec => sec.classList.remove('active'));
            const activeTab = get(tabId);
            if (activeTab) {
                activeTab.classList.add('active');
                if (get('pageTitle')) get('pageTitle').textContent = target.textContent.trim();
            }
        });
    });

    async function showDashboard() {
        if (screens.authContainer) screens.authContainer.classList.add('hidden');
        if (screens.appScreens) screens.appScreens.classList.remove('hidden');
        
        const data = await chrome.storage.local.get({ thresholdDays: 5, legacyEnabled: false, legacyDays: 180, legacyEmail: '' });
        updateSegmentedUI('dashThresholdSelector', data.thresholdDays);
        
        const legacyToggle = get('legacyToggle');
        const legacyConfig = get('legacyConfig');
        if(legacyToggle) {
            legacyToggle.checked = data.legacyEnabled;
            if(data.legacyEnabled && legacyConfig) legacyConfig.classList.remove('hidden');
            legacyToggle.onchange = async (e) => {
                const enabled = e.target.checked;
                await chrome.storage.local.set({ legacyEnabled: enabled });
                if(legacyConfig) legacyConfig.classList.toggle('hidden', !enabled);
            };
            if(get('legacyEmail')) get('legacyEmail').value = data.legacyEmail;
            updateSegmentedUI('legacyDaysSelector', data.legacyDays);
        }
        
        await loadData();
        setInterval(loadData, 5000); 
    }

    // --- WebAuthn ---
    get('webauthnLoginBtn')?.addEventListener('click', async () => {
        const verifyBlob = await chrome.storage.local.get(['webAuthnKey']);
        if (verifyBlob.webAuthnKey) {
            if(confirm("Biometric Passkey Authentication Simulation.\nContinue?")) {
                const rawKey = new Uint8Array(atob(verifyBlob.webAuthnKey).split('').map(c => c.charCodeAt(0)));
                activeKey = await crypto.subtle.importKey('raw', rawKey, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
                chrome.runtime.sendMessage({ action: 'set_session_key', key: verifyBlob.webAuthnKey });
                showDashboard();
            }
        }
    });

    // --- Data Loading ---
    async function loadData() {
        if (!activeKey) return;
        const d = await chrome.storage.local.get({ vault: [], thresholdDays: 5, email: 'User' });
        if (get('userEmailDisplay')) get('userEmailDisplay').textContent = d.email;
        
        const thresholdMillis = d.thresholdDays * 60 * 1000;
        const now = Date.now();
        let dormantCount = 0, leakedCount = 0, weakCount = 0;
        
        const statusData = { active: 0, dormant: 0, leaked: 0 };
        const entropyBuckets = { 'Centuries': 0, 'Years': 0, 'Days': 0, 'Minutes': 0 };
        const tableBody = get('vaultTableBody');
        if(!tableBody) return;
        tableBody.innerHTML = '';

        for (const item of d.vault) {
            const isDormant = (now - item.lastUsed) > thresholdMillis;
            const pass = (await decrypt(item.passwordBlob, activeKey)) || '';
            const entropy = calculateEntropy(pass);
            const isWeak = entropy.score <= 1;
            const isLeaked = item.isLeaked;

            if (isDormant) { dormantCount++; statusData.dormant++; } else { statusData.active++; }
            if (isWeak) weakCount++;
            if (isLeaked) { leakedCount++; statusData.leaked++; }

            if (entropy.score === 4) entropyBuckets['Centuries']++;
            else if (entropy.score === 3) entropyBuckets['Years']++;
            else if (entropy.score === 2) entropyBuckets['Days']++;
            else entropyBuckets['Minutes']++;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td><div style="font-weight:800">${item.site}</div></td>
                <td style="font-weight:600; color:var(--text-muted)">${item.username}</td>
                <td><span style="font-size:0.75rem; font-weight:700; color:${entropy.color}">${entropy.text}</span></td>
                <td style="font-size:0.8rem; font-weight:600; color:var(--text-muted)">${new Date(item.lastUsed).toLocaleString([], {month:'short', day:'numeric'})}</td>
                <td>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <span class="status-pill ${isDormant ? 'status-dormant' : 'status-active'}">${isDormant ? 'DORMANT' : 'ACTIVE'}</span>
                        ${isLeaked ? '<span class="status-pill status-leaked">LEAKED</span>' : ''}
                    </div>
                </td>
                <td style="text-align:right">
                    <div style="display:flex; gap:8px; justify-content:flex-end; align-items:center;">
                        <button class="icon-action btn-copy" data-id="${item.id}">COPY</button>
                        <button class="icon-action btn-edit" data-id="${item.id}">EDIT</button>
                        <button class="icon-action btn-del" data-id="${item.id}" style="color:#ef4444">DEL</button>
                    </div>
                </td>
            `;
            tableBody.appendChild(row);
        }
        
        attachTableListeners(d.vault);

        if(get('statTotal')) get('statTotal').textContent = d.vault.length;
        if(get('statDormant')) get('statDormant').textContent = dormantCount;
        if(get('statLeaked')) get('statLeaked').textContent = leakedCount;
        if(get('statWeak')) get('statWeak').textContent = weakCount;
        
        const healthScore = d.vault.length === 0 ? 100 : Math.round(100 - (((dormantCount*0.5) + (leakedCount*2) + weakCount) * (100 / (d.vault.length * 3.5))));
        const healthEl = get('statHealth');
        if(healthEl) {
            healthEl.textContent = Math.max(0, healthScore) + "%";
            healthEl.style.color = healthScore > 80 ? "#22c55e" : (healthScore > 50 ? "#f59e0b" : "#ef4444");
        }
        
        renderStatusChart(statusData);
        renderActivityChart(entropyBuckets);
    }

    function attachTableListeners(vault) {
        document.querySelectorAll('.btn-edit').forEach(btn => btn.onclick = async (e) => {
            const item = vault.find(v => v.id === parseInt(e.currentTarget.dataset.id));
            currentEditId = item.id;
            if(get('dashSiteUrl')) get('dashSiteUrl').value = item.site;
            if(get('dashUsername')) get('dashUsername').value = item.username;
            const p = await decrypt(item.passwordBlob, activeKey);
            if(get('dashPassword')) get('dashPassword').value = p || '';
            updateDashStrengthMeter(p || '');
            screens.editModal?.classList.remove('hidden');
        });

        document.querySelectorAll('.btn-copy').forEach(btn => btn.onclick = async (e) => {
            const item = vault.find(v => v.id === parseInt(e.currentTarget.dataset.id));
            const p = await decrypt(item.passwordBlob, activeKey);
            if (p) {
                navigator.clipboard.writeText(p);
                const originalText = e.currentTarget.textContent;
                e.currentTarget.textContent = 'DONE';
                setTimeout(() => e.currentTarget.textContent = originalText, 1000);
            }
        });

        document.querySelectorAll('.btn-del').forEach(btn => btn.onclick = async (e) => {
            if(confirm("Delete this credential?")) {
                const id = parseInt(e.currentTarget.dataset.id);
                const updatedVault = vault.filter(v => v.id !== id);
                await chrome.storage.local.set({ vault: updatedVault });
                loadData();
            }
        });
    }

    // Chart logic
    let sChart=null, aChart=null;
    function renderStatusChart(data) {
        const ctx = get('statusChart');
        if(!ctx) return;
        if (sChart) sChart.destroy();
        sChart = new Chart(ctx, {
            type: 'doughnut', data: { labels: ['Active', 'Dormant', 'Leaked'], datasets: [{ data: [data.active, data.dormant, data.leaked], backgroundColor: ['#a1a1aa', '#f59e0b', '#dc2626'] }] },
            options: { maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });
    }
    function renderActivityChart(buckets) {
        const ctx = get('activityChart');
        if(!ctx) return;
        if (aChart) aChart.destroy();
        aChart = new Chart(ctx, {
            type: 'bar', data: { labels: Object.keys(buckets), datasets: [{ label: 'Accounts', data: Object.values(buckets), backgroundColor: '#18181b' }] },
            options: { maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });
    }

    // Event Listeners for UI
    get('addNewDashBtn')?.addEventListener('click', () => {
        currentEditId = null;
        ['dashSiteUrl', 'dashUsername', 'dashPassword'].forEach(id => { if(get(id)) get(id).value = ''; });
        updateDashStrengthMeter('');
        screens.editModal?.classList.remove('hidden');
    });
    
    get('cancelDashEdit')?.addEventListener('click', () => screens.editModal?.classList.add('hidden'));
    get('dashPassword')?.addEventListener('input', (e) => updateDashStrengthMeter(e.target.value));
    
    get('dashGeneratePassBtn')?.addEventListener('click', () => {
        const p = Array.from(crypto.getRandomValues(new Uint8Array(20))).map(x => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*".charAt(x%72)).join('');
        if(get('dashPassword')) {
            get('dashPassword').value = p;
            updateDashStrengthMeter(p);
        }
    });

    get('saveDashBtn')?.addEventListener('click', async () => {
        const site = get('dashSiteUrl')?.value;
        const user = get('dashUsername')?.value;
        const pass = get('dashPassword')?.value;
        if(!site || !user || !pass) return;
        
        const encryptedPass = await encrypt(pass, activeKey);
        const data = await chrome.storage.local.get({ vault: [] });
        if(currentEditId) data.vault = data.vault.map(i => i.id === currentEditId ? { ...i, site, username:user, passwordBlob: encryptedPass, lastUsed: Date.now(), isLeaked: false, leaks: 0 } : i);
        else data.vault.push({ id: Date.now(), site, username: user, passwordBlob: encryptedPass, lastUsed: Date.now(), notified: false, isLeaked: false, leaks: 0 });
        
        await chrome.storage.local.set({ vault: data.vault });
        screens.editModal?.classList.add('hidden');
        loadData();
    });

    function updateDashStrengthMeter(pass) {
        const e = calculateEntropy(pass);
        const bar = get('dashStrengthBar');
        const txt = get('dashStrengthText');
        if(bar) { bar.style.width = (e.score * 25) + '%'; bar.style.backgroundColor = e.color; }
        if(txt) { txt.textContent = pass ? `Strength: ${e.text}` : ''; txt.style.color = e.color; }
    }

    // Settings
    document.querySelectorAll('#dashThresholdSelector button').forEach(b => b.onclick = async (e) => {
        const v = parseInt(e.target.dataset.value);
        await chrome.storage.local.set({ thresholdDays: v });
        updateSegmentedUI('dashThresholdSelector', v);
    });

    document.querySelectorAll('#legacyDaysSelector button').forEach(b => b.onclick = async (e) => {
        const v = parseInt(e.target.dataset.value);
        await chrome.storage.local.set({ legacyDays: v });
        updateSegmentedUI('legacyDaysSelector', v);
    });

    get('saveLegacyBtn')?.addEventListener('click', async () => {
        const email = get('legacyEmail')?.value;
        await chrome.storage.local.set({ legacyEmail: email, legacyLastActive: Date.now() });
        alert("Digital Legacy updated.");
    });

    function updateSegmentedUI(id, val) { 
        document.querySelectorAll(`#${id} button`).forEach(b => b.classList.toggle('active', b.dataset.value == val)); 
    }

    get('deleteVaultDashBtn')?.addEventListener('click', async () => {
        if(confirm("DANGER: This will permanently WIPE your vault. Continue?")) {
            await chrome.storage.local.clear();
            chrome.runtime.sendMessage({ action: 'lock_vault' });
            location.reload();
        }
    });
    
    get('exportBackupBtn')?.addEventListener('click', async () => {
        const d = await chrome.storage.local.get(null);
        const blob = new Blob([JSON.stringify(d)], {type: "application/json"});
        chrome.downloads.download({ url: URL.createObjectURL(blob), filename: "DormancyGuard_Backup.json" });
    });

    get('importBackupBtn')?.addEventListener('click', () => get('importBackupFile')?.click());
    get('importBackupFile')?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => {
            try {
                const parsed = JSON.parse(ev.target.result);
                if (parsed.vault && parsed.salt) {
                    await chrome.storage.local.set(parsed);
                    alert("Backup restored.");
                    location.reload();
                }
            } catch (err) { alert("Invalid backup."); }
        };
        reader.readAsText(file);
    });

    // Auth Flows
    get('unlockBtn')?.addEventListener('click', async () => {
        const pass = get('masterPassword')?.value;
        const d = await chrome.storage.local.get(['salt', 'verify']);
        if(!d.salt) return;
        const salt = new Uint8Array(atob(d.salt).split('').map(c => c.charCodeAt(0)));
        const key = await deriveKey(pass, salt);
        const check = await decrypt(d.verify, key);
        if(check === "success") {
            const exp = await crypto.subtle.exportKey('raw', key);
            chrome.runtime.sendMessage({ action: 'set_session_key', key: btoa(String.fromCharCode(...new Uint8Array(exp))) });
            activeKey = key;
            showDashboard();
        } else {
            get('loginError')?.classList.remove('hidden');
        }
    });

    get('initVaultBtn')?.addEventListener('click', () => {
        const email = get('userEmail')?.value;
        const pass = get('newMasterPassword')?.value;
        const webAuthn = get('enableWebAuthnSetup')?.checked;
        if(!email || (pass && pass.length < 8)) { alert("Valid email and 8+ char password required."); return; }
        const randomOTP = Math.floor(100000 + Math.random() * 900000).toString();
        tempAccountData = { email, pass, webAuthn, otp: randomOTP };
        chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'Verification', message: `Your code is: ${randomOTP}`, priority: 2 });
        screens.setup?.classList.add('hidden');
        screens.verify?.classList.remove('hidden');
    });

    get('confirmVerifyBtn')?.addEventListener('click', async () => {
        const code = Array.from(document.querySelectorAll('.dash-otp')).map(i=>i.value).join('');
        if(tempAccountData && code === tempAccountData.otp) {
            const { email, pass, webAuthn } = tempAccountData;
            const salt = crypto.getRandomValues(new Uint8Array(16));
            const key = await deriveKey(pass, salt);
            const verifyBlob = await encrypt("success", key);
            
            let webAuthnKey = null;
            if (webAuthn) {
                const exp = await crypto.subtle.exportKey('raw', key);
                webAuthnKey = btoa(String.fromCharCode(...new Uint8Array(exp)));
            }

            await chrome.storage.local.set({ email, salt: btoa(String.fromCharCode(...salt)), verify: verifyBlob, vault: [], thresholdDays: 5, webAuthnEnabled: webAuthn, webAuthnKey, legacyEnabled: false, legacyDays: 180 });
            location.reload();
        } else {
            alert("Incorrect code.");
        }
    });

    document.querySelectorAll('.dash-otp').forEach((input, idx, inputs) => {
        input.addEventListener('keyup', (e) => {
            if (e.key >= 0 && e.key <= 9 && idx < 5) inputs[idx + 1].focus();
            else if (e.key === 'Backspace' && idx > 0) inputs[idx - 1].focus();
        });
    });
});