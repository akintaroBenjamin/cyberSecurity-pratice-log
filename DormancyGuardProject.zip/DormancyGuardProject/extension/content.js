/**
 * DORMANCY GUARD: ADVANCED AUTOMATION & SMART CAPTURE
 * Logic: Monitor page for Login/Signup, detect submissions, offer save/update.
 */

const site = window.location.hostname.replace('www.', '').toLowerCase();
let capturedUsername = "";
let capturedPassword = "";
let isVaultUnlocked = false;
let currentMatch = null;

// --- INITIALIZATION ---
async function updateVaultState() {
    if (!chrome.runtime?.id) return;
    try {
        const response = await chrome.runtime.sendMessage({ action: 'get_session_key' });
        isVaultUnlocked = !!(response && response.key);
        
        if (isVaultUnlocked) {
            const data = await chrome.storage.local.get({ vault: [] });
            currentMatch = data.vault.find(v => v.site.includes(site) || site.includes(v.site));
        }
    } catch (e) { isVaultUnlocked = false; }
}

// --- FORM DETECTION & INTERACTION ---
document.addEventListener('input', (e) => {
    const target = e.target;
    if (target.type === 'password') {
        capturedPassword = target.value;
        const userField = findUsernameField(target);
        if (userField) capturedUsername = userField.value;
    } else if (target.type === 'text' || target.type === 'email') {
        const passField = document.querySelector('input[type="password"]');
        if (passField) {
            capturedUsername = target.value;
            capturedPassword = passField.value;
        }
    }
});

// Detect form submission
function handleSubmission() {
    if (capturedPassword.length > 4 && isVaultUnlocked) {
        checkAndPromptAction();
    }
}

document.addEventListener('submit', () => {
    setTimeout(handleSubmission, 100);
});

document.addEventListener('click', (e) => {
    const btn = e.target.closest('button, input[type="submit"]');
    if (!btn) return;
    
    const text = btn.innerText?.toLowerCase() || btn.value?.toLowerCase() || "";
    const commonLabels = ["log in", "login", "sign in", "sign up", "create account", "continue", "next", "submit", "register"];
    
    if (commonLabels.some(label => text.includes(label))) {
        setTimeout(handleSubmission, 500);
    }
});

// --- ACTION LOGIC (SAVE vs UPDATE) ---
async function checkAndPromptAction() {
    if (!isVaultUnlocked) return;
    
    const data = await chrome.storage.local.get({ vault: [] });
    const user = capturedUsername || 'User';
    const existing = data.vault.find(v => (v.site === site || v.site.includes(site)) && v.username === user);
    
    if (existing) {
        showBanner("update", user);
    } else {
        showBanner("save", user);
    }
}

// --- UI: DYNAMIC BANNER ---
function showBanner(type, user) {
    if (document.getElementById('dg-automation-banner')) return;

    const isUpdate = type === "update";
    const banner = document.createElement('div');
    banner.id = 'dg-automation-banner';
    
    banner.style.cssText = "position: fixed; top: 0; left: 0; right: 0; background: #ffffff; color: #0f172a; padding: 12px 24px; z-index: 2147483647; box-shadow: 0 4px 20px rgba(0,0,0,0.15); display: flex; justify-content: center; align-items: center; font-family: 'Plus Jakarta Sans', system-ui, sans-serif; border-bottom: 2px solid #38bdf8; animation: dgSlideDown 0.4s ease-out;";

    const msg = isUpdate ? "Update password for <b>" + user + "</b>?" : "Save password for <b>" + user + "</b> to Dormancy Guard?";
    const btnText = isUpdate ? "Update" : "Save";

    banner.innerHTML = `
        <style>
            @keyframes dgSlideDown { from { transform: translateY(-100%); } to { transform: translateY(0); } }
            .dg-btn { padding: 8px 20px; border-radius: 8px; font-weight: 700; font-size: 13px; cursor: pointer; transition: 0.2s; border: none; }
            .dg-btn-primary { background: #0f172a; color: white; }
            .dg-btn-primary:hover { background: #1e293b; }
            .dg-btn-ghost { background: transparent; color: #64748b; margin-left: 8px; }
            .dg-content { display: flex; align-items: center; gap: 16px; max-width: 1000px; width: 100%; justify-content: space-between; }
        </style>
        <div class="dg-content">
            <div style="display:flex; align-items:center; gap:12px;">
                <div style="background:#f1f5f9; padding:6px; border-radius:8px; display:flex; color:#38bdf8;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                </div>
                <span style="font-size: 14px; font-weight: 500;">${msg}</span>
            </div>
            <div>
                <button id="dg-action-confirm" class="dg-btn dg-btn-primary">${btnText}</button>
                <button id="dg-action-ignore" class="dg-btn dg-btn-ghost">Ignore</button>
            </div>
        </div>
    `;

    document.body.appendChild(banner);

    document.getElementById('dg-action-ignore').onclick = () => banner.remove();
    document.getElementById('dg-action-confirm').onclick = async () => {
        const payload = {
            action: 'save_credential_secure',
            site: site,
            username: user,
            password: capturedPassword
        };
        
        const resp = await chrome.runtime.sendMessage(payload);
        if (resp && resp.success) {
            banner.querySelector('.dg-content').innerHTML = '<div style="display:flex; align-items:center; gap:8px; width:100%; justify-content:center; color:#22c55e;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg><span style="font-weight:700;">Password Processed Successfully!</span></div>';
            setTimeout(() => banner.remove(), 2000);
        } else {
            banner.remove();
        }
    };
}

// --- INPUT INITIALIZATION (Generator & Autofill Icons) ---
async function initializeIcons() {
    if (!chrome.runtime?.id) return;
    await updateVaultState();
    if (!isVaultUnlocked) return;

    const response = await chrome.runtime.sendMessage({ action: 'get_session_key' });
    document.querySelectorAll('input[type="password"]').forEach(input => {
        if (input.dataset.dgInjected) return;
        input.dataset.dgInjected = "true";

        if (currentMatch) {
            injectIcon(input, "autofill", response.key);
        } else {
            injectIcon(input, "generate", null);
        }
    });
}

function injectIcon(input, mode, key) {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = "position: relative; display: inline-flex; width: " + (input.offsetWidth ? input.offsetWidth + 'px' : '100%') + ";";
    
    const icon = document.createElement('div');
    const isGen = mode === "generate";
    
    icon.innerHTML = isGen ? 
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2.5"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>' :
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>';
    
    icon.title = isGen ? "Generate Secure Password" : "Autofill Dormancy Guard";
    icon.style.cssText = "position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; z-index: 10; display: flex; transition: 0.2s;";
    
    icon.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (isGen) {
            const pass = generateStrongPass();
            input.value = pass;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            showIconSuccess(icon);
        } else {
            handleAutofill(input, currentMatch, key, icon);
        }
    };

    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);
    wrapper.appendChild(icon);
}

// --- HELPERS ---
function generateStrongPass() {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+=-";
    let p = "";
    for (let i = 0; i < 18; i++) p += chars.charAt(Math.floor(Math.random() * chars.length));
    return p;
}

async function handleAutofill(input, match, sessionKeyB64, icon) {
    try {
        const rawKey = new Uint8Array(atob(sessionKeyB64).split('').map(c => c.charCodeAt(0)));
        const key = await crypto.subtle.importKey('raw', rawKey, 'AES-GCM', false, ['decrypt']);
        const ciphertext = new Uint8Array(atob(match.passwordBlob.ciphertext).split('').map(c => c.charCodeAt(0)));
        const iv = new Uint8Array(atob(match.passwordBlob.iv).split('').map(c => c.charCodeAt(0)));
        const pass = new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext));
        
        input.value = pass;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        const userField = findUsernameField(input);
        if (userField) {
            userField.value = match.username;
            userField.dispatchEvent(new Event('input', { bubbles: true }));
        }
        showIconSuccess(icon);
    } catch (e) { console.error(e); }
}

function showIconSuccess(icon) {
    const old = icon.innerHTML;
    icon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>';
    setTimeout(() => icon.innerHTML = old, 2000);
}

function findUsernameField(passInput) {
    const form = passInput.closest('form');
    if (form) {
        return form.querySelector('input[type="text"], input[type="email"]');
    }
    return document.querySelector('input[type="email"], input[name*="user"], input[name*="login"]');
}

updateVaultState();
setInterval(initializeIcons, 3000);
setInterval(updateVaultState, 10000);
