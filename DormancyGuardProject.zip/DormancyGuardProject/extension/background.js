// background.js (Central Security Hub)
let sessionKey = null; // Key stays in RAM only

chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create('dormancyCheck', { periodInMinutes: 1 });
});

async function resetAutoLock() {
    if (!sessionKey) return;
    const data = await chrome.storage.local.get({ autoLockMinutes: 15 });
    if (data.autoLockMinutes > 0) {
        chrome.alarms.create('autoLockTimer', { delayInMinutes: data.autoLockMinutes });
    } else {
        chrome.alarms.clear('autoLockTimer');
    }
}

// Helper for Encryption
async function encrypt(text, key) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return { 
        ciphertext: btoa(String.fromCharCode(...new Uint8Array(encrypted))), 
        iv: btoa(String.fromCharCode(...iv)) 
    };
}

async function decrypt(blob, key) {
    try {
        const binaryString = atob(blob.ciphertext);
        const ciphertext = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) ciphertext[i] = binaryString.charCodeAt(i);
        const ivString = atob(blob.iv);
        const iv = new Uint8Array(ivString.length);
        for (let i = 0; i < ivString.length; i++) iv[i] = ivString.charCodeAt(i);
        const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
        return new TextDecoder().decode(decrypted);
    } catch (e) { return null; }
}

// HIBP k-Anonymity Leak Check
async function checkPwnedPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
    const prefix = hashHex.substring(0, 5);
    const suffix = hashHex.substring(5);

    try {
        const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
        const text = await response.text();
        const lines = text.split('\n');
        for (let line of lines) {
            const [hashSuffix, count] = line.split(':');
            if (hashSuffix && hashSuffix.trim() === suffix) {
                return parseInt(count);
            }
        }
    } catch (e) {
        console.error("HIBP API failed", e);
    }
    return 0;
}

// Perform Background Leak Audit
async function performLeakAudit() {
    if (!sessionKey) return; 
    
    try {
        const rawKey = new Uint8Array(atob(sessionKey).split('').map(c => c.charCodeAt(0)));
        const cryptoKey = await crypto.subtle.importKey('raw', rawKey, 'AES-GCM', false, ['decrypt', 'encrypt']);

        const data = await chrome.storage.local.get({ vault: [] });
        let changed = false;

        for (let item of data.vault) {
            const pass = await decrypt(item.passwordBlob, cryptoKey);
            if (pass) {
                const leaks = await checkPwnedPassword(pass);
                if (leaks > 0 && item.leaks !== leaks) {
                    item.leaks = leaks;
                    item.isLeaked = true;
                    changed = true;
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: 'icons/icon128.png',
                        title: 'CRITICAL: Password Leak Detected',
                        message: `Your password for ${item.site} was found in ${leaks} data breaches. Change it immediately.`,
                        priority: 2
                    });
                }
            }
        }
        if (changed) {
            await chrome.storage.local.set({ vault: data.vault });
        }
    } catch(e) {
        console.error("Audit failed", e);
    }
}

// Handle alarms
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'autoLockTimer') {
        sessionKey = null;
        console.log("[Background] Vault auto-locked due to inactivity.");
    }

    if (alarm.name === 'dormancyCheck') { 
        const data = await chrome.storage.local.get({ vault: [], thresholdDays: 5, legacyEnabled: false, legacyDays: 180, legacyLastActive: Date.now() });
        const thresholdMillis = data.thresholdDays * 60 * 1000;
        const now = Date.now();
        let changed = false;

        data.vault.forEach(item => {
            const isDormant = (now - item.lastUsed) > thresholdMillis;
            if (isDormant && !item.notified) {
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icons/icon128.png',
                    title: 'Dormancy Alert',
                    message: `Security Risk: ${item.site} has been inactive too long. Review it.`,
                    priority: 2
                });
                item.notified = true;
                changed = true;
            }
        });

        if (changed) {
            await chrome.storage.local.set({ vault: data.vault });
        }

        // Digital Legacy Check
        if (data.legacyEnabled && (now - data.legacyLastActive) > (data.legacyDays * 24 * 60 * 60 * 1000)) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icons/icon128.png',
                title: 'Digital Legacy Triggered',
                message: `Vault has been inactive for ${data.legacyDays} days. Emergency protocol initiated.`,
                priority: 2
            });
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'set_session_key') {
        sessionKey = request.key;
        console.log("[Background] Vault unlocked.");
        resetAutoLock();
        chrome.storage.local.set({ legacyLastActive: Date.now() });
        setTimeout(performLeakAudit, 5000);
    }

    if (request.action === 'lock_vault') {
        sessionKey = null;
        chrome.alarms.clear('autoLockTimer');
    }

    if (request.action === 'get_session_key') {
        if (sessionKey) resetAutoLock();
        sendResponse({ key: sessionKey });
    }

    if (request.action === 'reset_auto_lock') {
        resetAutoLock();
        chrome.storage.local.set({ legacyLastActive: Date.now() });
        sendResponse({ success: true });
    }

    if (request.action === 'save_credential_secure') {
        if (!sessionKey) { 
            sendResponse({ success: false, error: 'Vault locked' });
            return true;
        }

        (async () => {
            try {
                const rawKey = new Uint8Array(atob(sessionKey).split('').map(c => c.charCodeAt(0)));
                const cryptoKey = await crypto.subtle.importKey('raw', rawKey, 'AES-GCM', false, ['encrypt']);

                const encryptedPass = await encrypt(request.password, cryptoKey);
                const data = await chrome.storage.local.get({ vault: [] });
                
                const existingIndex = data.vault.findIndex(v => v.site === request.site && v.username === request.username);
                if (existingIndex > -1) {
                    data.vault[existingIndex] = { ...data.vault[existingIndex], passwordBlob: encryptedPass, lastUsed: Date.now(), notified: false, isLeaked: false, leaks: 0 };
                } else {
                    data.vault.push({ 
                        id: Date.now(), 
                        site: request.site, 
                        username: request.username, 
                        passwordBlob: encryptedPass, 
                        lastUsed: Date.now(), 
                        notified: false,
                        isLeaked: false,
                        leaks: 0
                    });
                }
                
                await chrome.storage.local.set({ vault: data.vault });
                sendResponse({ success: true });
                setTimeout(performLeakAudit, 1000); // Trigger audit on new save
            } catch (err) {
                console.error(err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true; 
    }
    return true;
});